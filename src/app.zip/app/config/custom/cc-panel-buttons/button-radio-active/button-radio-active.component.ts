import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { cbtn, Botones } from '../buttons.componente';

@Component({
  selector: 'app-button-radio-active',
  templateUrl: './button-radio-active.component.html',
  styleUrls: ['./button-radio-active.component.css']
})


export class ButtonRadioActiveComponent implements OnInit {
  public radioGroupForm: FormGroup;
  @Input() title: string;
  @Input() groupButton: cbtn[];
  @Input() filtroBoton;
  @Input() pparams: any;
  @Input() style: any;
  public agrupacion: cbtn[] = [];
  public filtrado;
  //generalGroup:Botones; 

  constructor(private formBuilder: FormBuilder, private _boton:Botones) { }

  ngOnInit() {
    this.radioGroupForm = this.formBuilder.group({
      'model': 1
    });

    if (this.style == undefined || this.style == '') {
      this.style = 'panel-info';
    }
    this.validateData();
  }

  validateData() {
    this.filtrado = this.filtroBoton;
    if (this.filtrado != null && this.filtrado != undefined) {
      var pp = this.pparams;
      this.groupButton.forEach(element => {
        if (element.permiso) {
          var b: any = {};
          b = (element);
          if (b.boton.datoBadge != undefined) {
            b.pDatoBagde = eval("pp." + b.boton.datoBadge);
          } else {
            b.pDatoBagde = 'C';
          }
          if (b.paramAccion != "" && b.paramAccion != undefined) {
            var a = { v1: b.paramAccion, v2: pp };
            b.paramAccion = a;
          } else { b.paramAccion = pp; };
          this.agrupacion.push(b);
        }
      });
    } else {
      this.agrupacion = this.groupButton;
    }
    console.log('Botones PanelButtons: ');
    console.log(this.agrupacion);
    console.log('Filtro botones PanelButtons: ' + this.filtrado);

  }

  function2(value1: any, value2: any) {
    console.log('accion: ' + value1);
    console.log('paramaccion: ' + value2);
    if (value1 === this._boton.doThing.prototype.name) {
      this._boton.doThing(value1,value2);
    }
    if (value1 === this._boton.doThing2.prototype.name) {
      this._boton.doThing2();
    }
  }


}