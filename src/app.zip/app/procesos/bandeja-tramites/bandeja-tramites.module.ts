import { AppMaterialModule } from './../../config/app-material/app-material.module';
import { BandejaTramitesRoutingModule } from './bandeja-tramites-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BandejaTramitesComponent } from './bandeja-tramites.component';


@NgModule({
  declarations: [BandejaTramitesComponent],
  imports: [
    CommonModule,
    BandejaTramitesRoutingModule,
    AppMaterialModule
  ]
})
export class BandejaTramitesModule { }
