import { FilterByOriginPipe } from './filter-by-origin.pipe';

describe('FilterByOriginPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByOriginPipe();
    expect(pipe).toBeTruthy();
  });
});
