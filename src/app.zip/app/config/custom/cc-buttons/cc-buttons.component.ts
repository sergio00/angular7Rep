import { Component, OnInit, Input } from '@angular/core';
import { cbtn, Botones } from '../cc-panel-buttons/buttons.componente';

@Component({
  selector: 'app-cc-buttons',
  templateUrl: './cc-buttons.component.html',
  styleUrls: ['./cc-buttons.component.css']
})
export class CcButtonsComponent implements OnInit {
  @Input() grupoBotones: cbtn[];
  @Input() filtroBotones;
  @Input() parametros;
  public agrupacion: cbtn[] = [];
  public filtrado;

  //<cc-buttons pbtns="vm.buttons" pfilterbtns="ctdet" pparam="{{c}}" />

  constructor(private _boton:Botones) { }

  ngOnInit() {
    this.validateData();
  }

  validateData() {
    this.filtrado = this.filtroBotones;    
    if (this.filtrado != null && this.filtrado != undefined) {
      var pp = this.parametros;
      this.grupoBotones.forEach(element => {
        if (element.permiso) {
          var b: any = {};
          b = (element);
          if (b.boton.datoBadge != undefined) {
            b.pDatoBagde = eval("pp." + b.boton.datoBadge);
          } else {
            b.pDatoBagde = 'C';
          }
          if (b.paramAccion != ""&& b.paramAccion != undefined) {
            var a = { v1: b.paramAccion, v2: pp };
            b.paramAccion = a;
          } else { b.paramAccion = pp; };
          this.agrupacion.push(b);
        }
      });
    }else{
      this.agrupacion = this.grupoBotones;
    }
    console.log('Botones CCButons: ');
    console.log(this.agrupacion);
    console.log('Filtro botones CCButons: ' + this.filtrado);

  }

  function2(value1: any, value2: any) {
    console.log('accion: ' + value1);
    console.log('paramaccion: ' + value2);
    if (value1 === this._boton.doThing.prototype.name) {
      this._boton.doThing(value1,value2);
    }
    if (value1 === this._boton.doThing2.prototype.name) {
      this._boton.doThing2();
    }
  }
}
