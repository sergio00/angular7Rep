import { NgbCollapse } from '@ng-bootstrap/ng-bootstrap';
import { CdClickDirective } from './directivas/cd-click.directive';
import { FormsModule } from '@angular/forms';
import { ButtonRadioActiveComponent } from './cc-panel-buttons/button-radio-active/button-radio-active.component';
import { FilterByOriginPipe } from './pipe/filter-by-origin.pipe';
import { CcButtonsComponent } from './cc-buttons/cc-buttons.component';
import { CcPanelGroupComponent } from './cc-panel-group.component';
import { CommonModule } from '@angular/common';
import { CcPanelComponent } from './cc-panel.component';

import { NgModule } from '@angular/core';
import { Botones } from './cc-panel-buttons/buttons.componente';

@NgModule({
  declarations: [
    CcPanelComponent,
    CcPanelGroupComponent,
    CcButtonsComponent,
    FilterByOriginPipe
    
    
    
  ],
  imports: [
    CommonModule,
    FormsModule,
    
  ],
  exports: [
    CcPanelComponent,
    CcPanelGroupComponent,
    CcButtonsComponent,
    FilterByOriginPipe
    
        
  ],
  providers: [Botones,NgbCollapse]

})
export class AppCustomModule {}
