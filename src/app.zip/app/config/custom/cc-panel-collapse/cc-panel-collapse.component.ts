import { Component, Input } from '@angular/core';
import { NgbCollapse } from '@ng-bootstrap/ng-bootstrap';
import { cbtn, Botones } from '../cc-panel-buttons/buttons.componente';

@Component({
  selector: 'app-cc-panel-collapse',
  templateUrl: './cc-panel-collapse.component.html',
  styleUrls: ['./cc-panel-collapse.component.css']
  //providers: [NgbAccordionConfig]// add the NgbAccordionConfig to the component providers
})
export class CcPanelCollapseComponent extends Botones {
  @Input() title: string;
  @Input() title2: string;
  @Input() groupButton: cbtn[];
  @Input() filtroBoton: string;
  @Input() pcolapse: any;
  @Input() style: any;
  @Input() precoger: any;
  @Input() pparams: any;
  public agrupacion: cbtn[] = [];
  public isCollapsed: any;
  public filtro: string;
  //config: NgbAccordionConfig
  constructor(public collapse: NgbCollapse, private _boton: Botones) {
    super();
  }

  function2(value1: any, value2: any) {
    console.log('accion: ' + value1);
    console.log('paramaccion: ' + value2);
    if (value1 === this._boton.doThing.prototype.name) {
      this._boton.doThing(value1,value2);
    }
    if (value1 === this._boton.doThing2.prototype.name) {
      this._boton.doThing2();
    }
  }

  ngOnInit() {
    if (this.precoger == undefined || this.precoger == '') {
      this.isCollapsed = true;
    }
    if (this.style == undefined || this.style == '') {
      this.style = 'panel-info';
    }

    this.validateData();
  }

  validateData() {
    this.filtro = this.filtroBoton;
    if (this.filtro != null && this.filtro != undefined) {
      var pp = this.pparams;
      this.groupButton.forEach(element => {
        if (element.permiso) {
          var b: any = {};
          b = (element);
          if (b.boton.datoBadge != undefined) {
            b.pDatoBagde = eval("pp." + b.boton.datoBadge);
          } else {
            b.pDatoBagde = 'C';
          }
          if (b.paramAccion != "") {
            var a: any = { v1: b.paramAccion, v2: pp };
            b.paramAccion = a;
          } else { b.paramAccion = pp; };
          this.agrupacion.push(b);
        }
      });
    } else {
      this.agrupacion = this.groupButton;
    }
    console.log('BotonesColapse: ');
    console.log(this.agrupacion);
    console.log('Filtro botonesColapse: ' + this.filtro);

  }


}