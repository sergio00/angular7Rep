import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusqDetalleComponent } from './busq-detalle.component';
import { BusqDetalleRoutingModule } from './busq-detalle-routing.module';

@NgModule({
  declarations: [BusqDetalleComponent],
  imports: [
    CommonModule,
    BusqDetalleRoutingModule
    
    
  ]
})
export class BusqDetalleModule { }
