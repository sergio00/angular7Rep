import { Tramites } from './modelo/tramites';
import { BandejaTramitesService } from './bandeja-tramites.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bandeja-tramites',
  templateUrl: './bandeja-tramites.component.html',
  styleUrls: ['./bandeja-tramites.component.css']
})
export class BandejaTramitesComponent implements OnInit {

  constructor(private router:Router,
              private Bandtramitesservice:BandejaTramitesService) { }

  displayedColumns: string[] = ['id', 'nombres', 'fecha','actions'];

  public tramites: Tramites[] = [];


  ngOnInit() {
    this.cargarDatos();
  }
  consultar(){
    this.router.navigateByUrl('/procesos/detalleBusqueda');
  }

cargarDatos() : void{
   
  this.Bandtramitesservice.getList().subscribe(
              tramite => {
                            this.tramites = tramite;
                            console.log(this.tramites);
                          }
                                              );
   
   

}


}
