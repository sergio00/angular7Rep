import { cbtn, Botones } from './../../config/custom/cc-panel-buttons/buttons.componente';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-busq-detalle',
  templateUrl: './busq-detalle.component.html',
  styleUrls: ['./busq-detalle.component.css']
  
})
export class BusqDetalleComponent implements OnInit {

  public grupoMantenimiento1: cbtn[] ;


  constructor(private router: Router,public botones:Botones) {
    this.grupoMantenimiento1 = this.botones.getBotones();

   }

  ngOnInit() {
  }

  regresar(){

    this.router.navigateByUrl('/procesos');
  }
  alerta(){
    alert("REgistro");
  }

}
