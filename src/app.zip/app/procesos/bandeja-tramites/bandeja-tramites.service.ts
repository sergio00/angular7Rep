import { Observable } from 'rxjs';
import { Tramites } from './modelo/tramites';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BandejaTramitesService {

  constructor(private httpClient: HttpClient) {

   }

  public getList(): Observable<Tramites[]> {
    return this.httpClient.get<Tramites[]>('http://localhost:7778/listTramites');
  }

}
