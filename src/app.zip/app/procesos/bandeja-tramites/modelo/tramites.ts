export interface Tramites {
    id: number;
    nombres: string;
    fecha: string;
}