import { validateConfig } from '@angular/router/src/config';

interface boton{
    icon?: string,
    texto?: string,
    datoBadge?:any
}

export interface cbtn {
    orig?: string,
    accion?: any ,
    paramAccion?: any,
    boton?: boton,
    permiso?: any,
    showtxt?: any,
    showimg?: any,
    showbadge?: any,
    clase?: any
}


export class Botones {
    public todos: cbtn[];
    name1 : any ;

    constructor() {
        //Object.setPrototypeOf(Botones.prototype.doThing,{name:"doThing"});
        this.doThing.prototype.name="doThing";
        this.doThing2.prototype.name="doThing2";
        //this.name1= Botones.prototype.doThing.prototype.constructor.__proto__.name;
        //this.name1= Botones.prototype.doThing.prototype.name;
     }

/*
{orig:"vistasExcep",accion:$scope.hsdiv,paramAccion:false,
cbtn:{icon:"glyphicon glyphicon-remove",texto:"Cerrar Vista"},permiso:true,showtxt:true,showimg:true,showbadge:false}
 */
    public getBotones() {
         this.todos = [
            {
                orig: "aprobarRegla",
                accion: this.doThing2.prototype.name , paramAccion: "X",
                boton: { icon: "fa fa-search", texto: "Aprobar" },
                permiso: true,
                showtxt: true,
                showimg: true,
                showbadge: false,
                clase:"btn-primary"

            },
            {
                orig: "aprobarRegla2",
                accion: "ok", paramAccion: "",
                boton: { icon: "fa fa-search", texto: "Cancelar" },
                permiso: false,
                showtxt: true,
                showimg: true,
                showbadge: false,
                clase:"btn-primary"

            },
            {
                orig: "aprobarRegla3",
                accion: "ok", paramAccion: "",
                boton: { icon: "fa fa-search", texto: "Consulta" },
                permiso: true,
                showtxt: true,
                showimg: true,
                showbadge: false,
                clase:"btn-primary"

            },
            {
                orig: "aprobarRegla4",
                accion: this.doThing.prototype.name, paramAccion: "",
                boton: { icon: "fa fa-search", texto: "Consulta" },
                permiso: true,
                showtxt: false,
                showimg: true,
                showbadge: false,
                clase:"btn-primary"

            }

        ]
        return this.todos;
    }


     doThing(value1: any, valu2: any):void  {
        
        //Botones.prototype.doThing.prototype.name='doThing';
        console.log('llamada de funcion 1');
        console.log('valor1 ' + value1 + ', valor2 ' + valu2);
    };

     doThing2():void {
        console.log('llamada de funcion 2');

    }


}
