import { CcPanelGroupComponent } from './../config/custom/cc-panel-group.component';
import { CcPanelComponent } from './../config/custom/cc-panel.component';
import { Botones } from './../config/custom/cc-panel-buttons/buttons.componente';
import { CcButtonsComponent } from './../config/custom/cc-buttons/cc-buttons.component';
import { FilterByOriginPipe } from './../config/custom/pipe/filter-by-origin.pipe';
import { CcPanelCollapseComponent } from './../config/custom/cc-panel-collapse/cc-panel-collapse.component';
import { ButtonRadioActiveComponent } from './../config/custom/cc-panel-buttons/button-radio-active/button-radio-active.component';
import { HomeComponent } from '../home/home.component';
import { HeaderComponent } from '../header/header.component';
import { LoginComponent } from '../login/login.component';
import { HomeLayoutComponent } from '../layouts/home-layout.component';
import { LoginLayoutComponent } from '../layouts/login-layout.component';



import { AuthGuard } from '../auth/auth.guard';
import { AuthService } from '../auth/auth.service';

import { CommonModule } from '@angular/common';

import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { HttpClientModule } from '@angular/common/http';
import { LayoutModule } from '@angular/cdk/layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from '../app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AppMaterialModule } from '../config/app-material/app-material.module';

import {
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
} from '@angular/material';


@NgModule({
    imports: [CommonModule,
        HttpClientModule,
        LayoutModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        ReactiveFormsModule,
        AppMaterialModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatBottomSheetModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatDatepickerModule,
        MatDialogModule,
        MatDividerModule,
        MatExpansionModule,
        MatGridListModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatNativeDateModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatRippleModule,
        MatSelectModule,
        MatSidenavModule,
        MatSliderModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        MatSortModule,
        MatStepperModule,
        MatTableModule,
        MatTabsModule,
        MatToolbarModule,
        MatTooltipModule,
        MatTreeModule,
        NgbModule
    ],
    declarations: [HomeComponent, HeaderComponent, LoginComponent, LoginLayoutComponent,
        HomeLayoutComponent, ButtonRadioActiveComponent, CcPanelCollapseComponent, FilterByOriginPipe, CcButtonsComponent,CcPanelComponent,CcPanelGroupComponent],
    exports: [HomeComponent, HeaderComponent, LoginComponent, LoginLayoutComponent,
        HomeLayoutComponent, ButtonRadioActiveComponent, CcPanelCollapseComponent,
        FilterByOriginPipe,
        CcButtonsComponent,
        CommonModule,
        HttpClientModule,
        LayoutModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        NgbModule,
        ReactiveFormsModule,
        AppMaterialModule,CcPanelComponent,CcPanelGroupComponent],
    providers: [AuthService, AuthGuard, Botones],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class ModuleGeneralImportModule { }
